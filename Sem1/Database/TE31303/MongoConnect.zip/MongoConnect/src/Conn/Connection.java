package Conn;


import com.mongodb.client.*;
import com.mongodb.client.model.*;

import java.util.Iterator;
import java.util.Scanner;

import com.mongodb.MongoClient; 
import com.mongodb.MongoCredential;  
import org.bson.Document;

public class Connection { 
   
   public static void main( String args[] ) {  
      
      // Creating a Mongo client 
      MongoClient mongo = new MongoClient( "10.10.10.51" , 27017 ); 
   
      // Creating Credentials 
      MongoCredential credential; 
      credential = MongoCredential.createCredential("31319", "31319", 
         "31319".toCharArray()); 
      System.out.println("Connected to the database successfully");  
      
      // Accessing the database 
      MongoDatabase database = mongo.getDatabase("31319"); 
      System.out.println("Credentials ::"+ credential);     
      
//      database.createCollection("from_java");
      MongoCollection<Document> collection = database.getCollection("from_java");
      Boolean isExit = false;
      while(!isExit) {
    	  System.out.println("MENU");
    	  System.out.println("1. Insert");
    	  System.out.println("2. Display");
    	  System.out.println("3. Delete");
    	  System.out.println("4. Update");
    	  System.out.println("5. Exit");
    	  
    	  Scanner sc = new Scanner(System.in);
    	  int ch = Integer.parseInt(sc.next());
    	  
    	  switch(ch) {
    	  case 	1: {
    		  int rno;
    		  String name;
    		  System.out.println("Enter Roll No: ");
    		  rno = Integer.parseInt(sc.next());
    		  System.out.println("Enter Name: ");
    		  name = sc.next();
    		  Document d = new Document("rno", rno);
    		  d.append("name", name);
    		  collection.insertOne(d);
    		  break;
    	  }
    	  case 2: {
    		  FindIterable<Document> iterDoc = collection.find();
    			int i = 1;
    			// Getting the iterator
    			Iterator it = iterDoc.iterator();
    			while (it.hasNext()) {
    				System.out.println(it.next());
    				i++;
    			}
    			
    			break;
    	  }
    	  case 3: {
    		  int rno;
    		  System.out.println("Enter Roll no to delete: ");
    		  rno = Integer.parseInt(sc.next());
    		  collection.deleteOne(Filters.eq("rno", rno));
    		  System.out.println("Document deleted successfully..");
    		  break;
    	  }
    	  case 4: {
    		  System.out.println("Enter Roll no to update: ");
    		  int rno;
    		  rno = Integer.parseInt(sc.next());
    		  String name;
    		  System.out.println("Enter new name: ");
    		  name = sc.next();
    		  collection.updateOne(Filters.eq("rno", rno), Updates.set("name", name));
    		  System.out.println("Document updated successfully...");
    		  
    		  break;
    	  }
    	  case 5:
    		  isExit = true;
    		  break;
    	  default: 
    		  System.out.println("Wrong Option");
    	  }
      }
   } 
}